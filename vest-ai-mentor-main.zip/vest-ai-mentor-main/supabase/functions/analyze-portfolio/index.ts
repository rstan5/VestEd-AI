import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const SYSTEM_PROMPT = `You are the AI Investment Professor at VestEd — equal parts hedge fund risk manager and patient teacher for Gen Z investors. You analyze portfolios AND teach the underlying strategy so the user actually learns to think like a pro.

Structure every response EXACTLY as follows using markdown:

## 💪 Strengths
- 3 bullets on what's working (diversification, momentum, sector exposure, cost basis, etc.). Reference real tickers and weights.

## ⚠️ Risks
- 3 bullets on concentration risk, correlation, sector/factor exposure, volatility, drawdown potential. Use specific numbers.

## 📚 Strategy Lesson
- 2-3 bullets teaching ONE relevant hedge fund concept tied to this portfolio (e.g. Sharpe ratio, beta hedging, sector rotation, position sizing, Kelly criterion, mean reversion, momentum, dollar-cost averaging, rebalancing). Explain it like the user is 18 and new to investing — clear, no jargon without a definition.

## 🎯 Recommendations to Maximize Returns
- 3 actionable moves. Each must include:
  - The specific action (e.g. "Trim AAPL from 45% to 25%")
  - A what-if scenario with estimated impact (e.g. "Reduces portfolio beta from 1.4 → 1.1, expected vol drops ~20%")
  - Which metric it improves (Sharpe, alpha, drawdown, diversification, expected return)

Keep bullets concise (1-2 sentences). Always reference actual tickers from the portfolio. Be direct and confident — like a professor who actually trades.`;

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { holdings, source, cashBalance } = await req.json();

    if (!holdings || !Array.isArray(holdings) || holdings.length === 0) {
      return new Response(JSON.stringify({ error: "Holdings array is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const totalValue = holdings.reduce((s: number, h: any) => s + (h.value || 0), 0);
    const holdingsSummary = holdings
      .map((h: any) => `${h.ticker}: ${h.shares} shares, ${h.weight.toFixed(1)}% weight, $${h.value.toLocaleString()} value${typeof h.change === "number" ? `, ${h.change >= 0 ? "+" : ""}${h.change.toFixed(2)}% unrealized P/L` : ""}`)
      .join("\n");

    const contextLine = source === "trade_lab"
      ? `This is the user's LIVE Trade Lab paper trading portfolio they're using to compete on VestEd${typeof cashBalance === "number" ? ` (uninvested cash: $${cashBalance.toLocaleString()})` : ""}. Tailor recommendations to help them climb the leaderboard.`
      : `This is a portfolio the user uploaded for analysis. Treat it as their real allocation and teach accordingly.`;

    const userPrompt = `${contextLine}\n\nPortfolio total value: $${totalValue.toLocaleString()}\n\nHoldings:\n${holdingsSummary}\n\nProvide the full analysis: Strengths, Risks, Strategy Lesson, and Recommendations to Maximize Returns.`;

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: userPrompt },
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limited — please wait a moment and try again." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please add funds in Settings." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(JSON.stringify({ error: "AI service error" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("analyze error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
