// Scheduled edge function: pulls fresh quotes from Finnhub and upserts them
// into stock_price_cache. All clients read from this cache instead of calling
// Finnhub directly, so we make at most ~1 batch of calls per minute regardless
// of user count.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const FINNHUB_BASE = "https://finnhub.io/api/v1";
const TICKERS = ["AAPL", "NVDA", "MSFT", "GOOGL", "META", "AMZN"];

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const apiKey = Deno.env.get("FINNHUB_API_KEY");
    if (!apiKey) {
      return new Response(JSON.stringify({ error: "FINNHUB_API_KEY not set" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const rows: Array<{ ticker: string; price: number; change: number; change_percent: number }> = [];

    await Promise.all(
      TICKERS.map(async (ticker) => {
        try {
          const resp = await fetch(`${FINNHUB_BASE}/quote?symbol=${ticker}&token=${apiKey}`);
          if (!resp.ok) return;
          const data = await resp.json();
          if (data.c && data.c > 0) {
            rows.push({
              ticker,
              price: data.c,
              change: data.d ?? 0,
              change_percent: data.dp ?? 0,
            });
          }
        } catch {
          // skip failed ticker
        }
      }),
    );

    if (rows.length > 0) {
      const { error } = await supabase
        .from("stock_price_cache")
        .upsert(rows.map((r) => ({ ...r, updated_at: new Date().toISOString() })), {
          onConflict: "ticker",
        });
      if (error) throw error;
    }

    return new Response(JSON.stringify({ updated: rows.length }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("refresh-stock-prices error:", err);
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
