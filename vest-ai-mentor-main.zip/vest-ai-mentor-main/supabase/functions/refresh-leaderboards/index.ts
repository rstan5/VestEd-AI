// Scheduled edge function: recomputes per-user and per-club returns from cached
// prices and writes them to user_returns_snapshot / club_returns_snapshot.
// Leaderboard reads then become cheap joins instead of heavy aggregates.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const STARTING_CASH = 100000;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    // 1. Build price map from cache
    const { data: priceRows, error: priceErr } = await supabase
      .from("stock_price_cache")
      .select("ticker, price");
    if (priceErr) throw priceErr;
    const priceMap = new Map<string, number>();
    (priceRows ?? []).forEach((r: any) => priceMap.set(r.ticker, Number(r.price)));

    // 2. Get all profiles + portfolios + positions
    const [profilesRes, portfoliosRes, positionsRes] = await Promise.all([
      supabase.from("profiles").select("user_id"),
      supabase.from("portfolios").select("user_id, cash_balance"),
      supabase.from("positions").select("user_id, ticker, shares, average_cost"),
    ]);
    if (profilesRes.error) throw profilesRes.error;
    if (portfoliosRes.error) throw portfoliosRes.error;
    if (positionsRes.error) throw positionsRes.error;

    const cashByUser = new Map<string, number>();
    (portfoliosRes.data ?? []).forEach((p: any) =>
      cashByUser.set(p.user_id, Number(p.cash_balance)),
    );

    const positionsValueByUser = new Map<string, number>();
    (positionsRes.data ?? []).forEach((pos: any) => {
      const px = priceMap.get(pos.ticker) ?? Number(pos.average_cost);
      const v = Number(pos.shares) * px;
      positionsValueByUser.set(
        pos.user_id,
        (positionsValueByUser.get(pos.user_id) ?? 0) + v,
      );
    });

    const userRows = (profilesRes.data ?? []).map((pr: any) => {
      const cash = cashByUser.get(pr.user_id) ?? STARTING_CASH;
      const posVal = positionsValueByUser.get(pr.user_id) ?? 0;
      const totalValue = cash + posVal;
      const returnPct = ((totalValue - STARTING_CASH) / STARTING_CASH) * 100;
      return {
        user_id: pr.user_id,
        total_value: Number(totalValue.toFixed(2)),
        return_pct: Number(returnPct.toFixed(2)),
        updated_at: new Date().toISOString(),
      };
    });

    if (userRows.length > 0) {
      const { error } = await supabase
        .from("user_returns_snapshot")
        .upsert(userRows, { onConflict: "user_id" });
      if (error) throw error;
    }

    // 3. Aggregate per club
    const { data: memberships, error: memErr } = await supabase
      .from("club_memberships")
      .select("club_id, user_id");
    if (memErr) throw memErr;

    const userReturnMap = new Map<string, number>();
    userRows.forEach((u) => userReturnMap.set(u.user_id, u.return_pct));

    const clubAgg = new Map<string, { sum: number; count: number }>();
    (memberships ?? []).forEach((m: any) => {
      const r = userReturnMap.get(m.user_id) ?? 0;
      const cur = clubAgg.get(m.club_id) ?? { sum: 0, count: 0 };
      cur.sum += r;
      cur.count += 1;
      clubAgg.set(m.club_id, cur);
    });

    const { data: allClubs, error: clubsErr } = await supabase
      .from("investment_clubs")
      .select("id");
    if (clubsErr) throw clubsErr;

    const clubRows = (allClubs ?? []).map((c: any) => {
      const agg = clubAgg.get(c.id) ?? { sum: 0, count: 0 };
      return {
        club_id: c.id,
        avg_return: agg.count > 0 ? Number((agg.sum / agg.count).toFixed(2)) : 0,
        member_count: agg.count,
        updated_at: new Date().toISOString(),
      };
    });

    if (clubRows.length > 0) {
      const { error } = await supabase
        .from("club_returns_snapshot")
        .upsert(clubRows, { onConflict: "club_id" });
      if (error) throw error;
    }

    return new Response(
      JSON.stringify({ users: userRows.length, clubs: clubRows.length }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    console.error("refresh-leaderboards error:", err);
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
