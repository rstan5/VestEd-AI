// Reads cached prices from stock_price_cache. The cache is refreshed every
// minute by the refresh-stock-prices scheduled function, so this endpoint
// never calls Finnhub and stays well within rate limits no matter how many
// users are connected.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const tickersParam = url.searchParams.get("tickers");
    if (!tickersParam) {
      return new Response(JSON.stringify({ error: "Missing 'tickers' query parameter" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const tickers = tickersParam
      .split(",")
      .map((t) => t.trim().toUpperCase())
      .filter((t) => /^[A-Z]{1,5}$/.test(t))
      .slice(0, 20);

    if (tickers.length === 0) {
      return new Response(JSON.stringify({ error: "No valid tickers provided" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { data, error } = await supabase
      .from("stock_price_cache")
      .select("ticker, price, change, change_percent")
      .in("ticker", tickers);

    if (error) throw error;

    const results: Record<string, { price: number; change: number; changePercent: number }> = {};
    (data ?? []).forEach((r: any) => {
      results[r.ticker] = {
        price: Number(r.price),
        change: Number(r.change),
        changePercent: Number(r.change_percent),
      };
    });

    return new Response(JSON.stringify(results), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("stock-prices error:", err);
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
