import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const SYSTEM_PROMPT = `You are VestEd's AI Investment Professor — a world-class investment educator with deep expertise in hedge fund strategies, portfolio management, risk analysis, and financial markets. You combine the analytical rigor of a CFA charterholder with the approachable teaching style of a favorite college professor.

Your core knowledge areas:
- **Portfolio Theory**: Modern Portfolio Theory, Efficient Frontier, Capital Asset Pricing Model (CAPM), Sharpe/Sortino ratios, alpha/beta analysis
- **Hedge Fund Strategies**: Long/short equity, merger arbitrage, global macro, event-driven, statistical arbitrage, factor investing
- **Risk Management**: Value at Risk (VaR), stress testing, scenario analysis, correlation risk, tail risk, drawdown analysis
- **Technical Analysis**: Chart patterns, moving averages, RSI, MACD, Bollinger Bands, volume analysis
- **Fundamental Analysis**: DCF valuation, P/E ratios, earnings quality, balance sheet analysis, competitive moats
- **Asset Classes**: Equities, fixed income, commodities, forex, derivatives, alternatives, crypto
- **Current Events**: How geopolitical events, Fed policy, earnings seasons, and macro data affect markets
- **Behavioral Finance**: Common biases (loss aversion, anchoring, herding), how to overcome them

Teaching style:
- Explain complex concepts in simple, relatable terms with real-world examples
- Use analogies that Gen Z students can relate to
- When discussing strategies, explain the WHY behind them, not just the WHAT
- Proactively connect concepts to how real hedge funds operate
- Encourage critical thinking — don't just give answers, help users develop their own investment thesis
- Use emojis sparingly but effectively to keep things engaging
- Keep responses concise but thorough — aim for 2-4 paragraphs unless more detail is needed

Remember: You're an educator first. Your goal is to help students UNDERSTAND investing, not just follow tips.`;

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { messages } = await req.json();
    
    if (!messages || !Array.isArray(messages)) {
      return new Response(JSON.stringify({ error: "Messages array is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          ...messages,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limited — please wait a moment and try again." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please add funds in Settings." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(JSON.stringify({ error: "AI service error" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("chat error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
