## Goal
Seed 50 AI bot "students" across 8 lesser-known college investment clubs so the leaderboards feel competitive from day one. One-time static seed, no ongoing simulation.

## Clubs (8, lesser-known schools)
- Bentley Finance Society
- Babson Capital Markets Club
- Bryant Bulldogs Investing
- Elon Phoenix Trading Group
- Trinity Bantam Capital
- Drexel Dragons Equity Club
- Loyola Marymount Wall Street Club
- Rollins Tars Investment Society

~6 bots per club + a couple owners = 50 total profiles.

## Bot identity
- 50 rows in `profiles` (with new `is_bot = true` column) — realistic Gen-Z names like "Maya Chen", "Jordan Patel", school-themed usernames (`@bentley_maya`, `@drexel_kai`).
- Avatars: `https://api.dicebear.com/7.x/avataaars/svg?seed={username}` (no storage).
- 50 matching `portfolios` rows with varied `cash_balance` (5k–40k remaining cash).
- 3–6 `positions` per bot across the 6 cached tickers (AAPL, NVDA, MSFT, META, GOOGL, AMZN). `average_cost` engineered relative to current cached prices to produce a believable return spread:
  - 3–5 stars at +30% to +60%
  - middle pack at +5% to +20%
  - tail at −5% to −15%
- Top bot capped around +60% so a real new user with one hot pick can plausibly climb.

## Clubs + memberships
- 8 `investment_clubs` rows, each `owner_id` = one of the bot UUIDs, plus `image_url` from DiceBear shapes.
- `club_memberships` rows: owner + ~5 members each. `handle_new_club` trigger auto-inserts the owner membership, so the seed only needs to insert non-owner members.

## Snapshots
After seeding, manually upsert `user_returns_snapshot` and `club_returns_snapshot` using the same math as `refresh-leaderboards` (computed inline in the seed script), so the leaderboard is populated immediately without waiting on the cron.

## Safety
- New `profiles.is_bot boolean default false` column → easy to query, hide, or delete bots later (`DELETE FROM profiles WHERE is_bot = true` cascades cleanly through portfolios/positions/memberships via user_id matching).
- Bots have no `auth.users` row (profiles.user_id has no FK to auth) → they can never log in. Done intentionally.

## Steps
1. **Migration:** add `is_bot` column to `profiles`.
2. **Seed (insert tool):** insert 8 clubs → 50 profiles → 50 portfolios → ~200 positions → club memberships → user/club return snapshots. All as a single SQL batch with deterministic UUIDs.
3. **Verify:** query the leaderboards to confirm the spread looks natural; spot-check `/users/:id` for one bot.

## Out of scope
- No scheduled bot trading (per your call — static only).
- No edge function changes.
- No frontend changes; existing Compete page already reads from these tables.
